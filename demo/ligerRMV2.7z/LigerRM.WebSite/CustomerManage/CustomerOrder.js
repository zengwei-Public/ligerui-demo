﻿$(function ()
{
    var tab = $("#tabcontainer").ligerTab();

    var ordersLoaded = false;

    tab.bind('afterSelectTabItem', function (tabid)
    {
        if (tabid != "orders" || ordersLoaded) return;
        ordersLoaded = true;
        var where = { op: 'and', rules: [{ field: 'CustomerID', value: currentID, op: 'equal'}] };
        $("#ordergrid").ligerGrid({
            columns:
                [
                { display: '订单序号', name: 'OrderID' },
                { display: '运费', name: 'Freight', width: 50, align: 'right' },
                { display: '收货人', name: 'ShipName', width: 260, align: 'left' },
                { display: '收货地址', name: 'ShipAddress', width: 320, align: 'left' },
                { display: '收货城市', name: 'ShipCity', width: 100, align: 'left' },
                { display: '收货国家', name: 'ShipCountry' }
                ], showToggleColBtn: false, width: '99%', height: 500, rowHeight: 24,
            columnWidth: 100, frozen: false, sortName: 'OrderID', usePager: false, checkbox: false,
            url: isAddNew ? null : '../handler/grid.ashx?view=Orders',
            parms: { where: JSON2.stringify(where) },
            detail: { onShowDetail: ShowProjects, height: 'auto' }
        });

        $("input.quantity").live('change', function ()
        {
            var Quantity = this.value;
            var ProductID = $(this).attr("ProductID");
            var OrderID = $(this).attr("OrderID");
            if (!Quantity || !ProductID || !OrderID || Quantity < 0) return false;
            LG.ajax({
                type: 'AjaxOrderManage', method: 'UpdateQuantity',
                data: { Quantity: Quantity, ProductID: ProductID, OrderID: OrderID },
                loading: '正在更新数量中...',
                success: function ()
                {
                    LG.tip('数量更新成功!');
                },
                error: function (message)
                {
                    LG.tip('数量更新失败:' + message);
                }
            });
        });

        return;

        function ShowProjects(row, detailPanel, callback)
        {
            var where = { op: 'and', rules: [{ field: 'OrderID', value: row.OrderID, op: 'equal'}] };
            var grid = document.createElement('div');
            $(detailPanel).append(grid);
            $(grid).addClass("projectgrid").css('margin', 10).ligerGrid({
                columns:
                    [
                        { display: '产品ID', name: 'ProductID', align: 'left' },
                        { display: '产品名', name: 'ProductName', width: 260, align: 'left' },
                        { display: '单价', name: 'UnitPrice', width: 120, align: 'right' },
                        { display: '数量', name: 'Quantity', width: 120, align: 'right', render: QuantityRender }
                    ], showToggleColBtn: false, width: 620, height: 'auto', rowHeight: 24,
                columnWidth: 100, frozen: false, usePager: false, checkbox: false, mouseoverRowCssClass: null,
                alternatingRow: false,
                url: isAddNew ? null : '../handler/grid.ashx?view=Order Details Extended',
                parms: { where: JSON2.stringify(where) }
            });
        }

        function QuantityRender(row)
        {

            var inputhtml = '<input type="text" class="quantity" style="width: 40px;text-align:right;border:1px solid #DDDDDD;background:#FFFFFF;height:20px; line-height:20px;margin:3px;" value=' + row.Quantity + ' ProductID = "' + row.ProductID + '" OrderID="' + row.OrderID + '" />';

            return inputhtml;

        }

    });
});