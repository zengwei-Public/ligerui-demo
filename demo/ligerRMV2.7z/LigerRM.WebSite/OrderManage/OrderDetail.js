﻿$(function ()
{
    var tab = $("#tabcontainer").ligerTab();

    var orderDetailLoaded = false;
    var productGrid = null;
    var productWin = null;
    //全局对象
    window.orderDetailGrid = null;

    tab.bind('afterSelectTabItem', function (tabid)
    {
        if (tabid != "orderdetail" || orderDetailLoaded) return;
        orderDetailLoaded = true;

        var where = { op: 'and', rules: [{ field: 'OrderID', value: currentID, op: 'equal'}] };
        orderDetailGrid = $("#orderdetailgrid").ligerGrid({
            columns:
                    [
                        { display: '产品名', name: 'ProductName', width: 260, align: 'left' },
                        { display: '单价', name: 'UnitPrice', width: 60, align: 'right', editor: { type: 'numberbox' }, type: 'currency' },
                        { display: '数量', name: 'Quantity', width: 60, align: 'right', editor: { type: 'numberbox' }, type: 'numberbox' },
                        { display: '折扣', name: 'Discount', width: 60, align: 'right', editor: { type: 'percent' }, type: 'percent' },
                        { display: '总计', width: 60, align: 'right', render: amountRender }
                    ], showToggleColBtn: false, width: 620, height: 'auto', rowHeight: 24,
            columnWidth: 100, frozen: false, usePager: false, checkbox: false, mouseoverRowCssClass: null,
            alternatingRow: false, enabledEdit: true,
            url: isAddNew ? null : '../handler/grid.ashx?view=Order Details Extended',
            parms: { where: JSON2.stringify(where) }, toolbar: getTollbar()
        });

    });

    function getTotalSummary()
    {
        var o = {};

        o.render = function (suminf, column, cell)
        {
            return '<div>总计:' + suminf.sum + '</div>';
        };
        o.align = 'right'
        return o;
    }

    function amountRender(rowdata)
    {
        var UnitPrice = rowdata.UnitPrice || 0;
        var Quantity = rowdata.Quantity || 0;
        var Discount = rowdata.Discount || 0;
        return (UnitPrice * Quantity * (1 - Discount)).toFixed(2);
    }

    function getTollbar()
    {
        var o = {
            text: '引入',
            img: '../lib/icons/32X32/import.png'
        };
        o.click = function ()
        {
            showProduct();
        };

        var itemDel = {
            text: '删除',
            img: '../lib/icons/silkicons/delete.png'
        };
        itemDel.click = function ()
        {
            orderDetailGrid.deleteSelectedRow();
        };

        return { items: [o, itemDel] };

    }


    function showProduct()
    {
        if (productWin)
        {
            productWin.show();
        }
        else
        {
            var productPanle = $("<div></div>");
            var proeuctSearchForm = $("<form></form>");
            var gridPanle = $("<div></div>").width(700).height(300);

            productPanle.append(proeuctSearchForm).append(gridPanle);

            //grid
            productGrid = gridPanle.ligerGrid({
                columns: [
            { display: "产品名称", name: "ProductName", width: 180, align: 'left' },
            { display: "折扣", name: "QuantityPerUnit", width: 180, align: 'left' },
            { display: "单价", name: "UnitPrice", width: 180, align: 'right' },
            { display: "库存量", name: "UnitsInStock", width: 180, align: 'right' },
            { display: "订购量", name: "UnitsOnOrder", width: 180, align: 'right' },
            { display: "订购", name: "ReorderLevel", width: 180, align: 'right' }
            ], pageSize: 20,
                url: '../handler/grid.ashx?view=Products', sortName: 'ProductID',
                width: '98%', height: 300, checkbox: true
            });
            //dialog
            productWin = $.ligerDialog.open({
                title: '选择产品',
                width: 800, height: 420, top: 50,
                target: productPanle,
                buttons: [
                 { text: '选择', onclick: function (item, dialog)
                 {
                     selectProduct(); dialog.hide();
                 } 
                 },
                 { text: '取消', onclick: function (item, dialog) { dialog.hide(); } }
                ]
            });

            //搜索
            proeuctSearchForm.ligerForm({
                fields: [{ display: "产品名称", name: "ProductName", labelWidth: 80, width: 150, space: 30, type: "text", cssClass: "field"}],
                toJSON: JSON2.stringify
            });

            //搜索按钮、高级搜索按钮 
            var containerBtn1 = $('<li style="margin-right:9px"></li>');
            var containerBtn2 = $('<li></li>');
            $("ul:first", proeuctSearchForm)
                .append(containerBtn1)
                .append(containerBtn2)
                .after('<div class="l-clear"></div>');
            LG.addSearchButtons(proeuctSearchForm, productGrid, containerBtn1, containerBtn2);
        }
    }

    function selectProduct()
    {
        var checked = productGrid.getSelecteds();
        $(checked).each(function ()
        {
            if (productExist(this.ProductID)) return;

            // ligerGrid _addData bug fixed
            if (!orderDetailGrid.currentData.Rows)
                orderDetailGrid.currentData.Rows = [];

            orderDetailGrid.addRow({
                ProductName: this.ProductName,
                ProductID: this.ProductID,
                UnitPrice: this.UnitPrice,
                Quantity: 0,
                Discount: 0
            });
        });
    }

    function productExist(ProductID)
    {
        var rows = orderDetailGrid.rows;
        for (var i = 0, l = rows.length; i < l; i++)
        {
            var o = rows[i];
            if (o.ProductID == ProductID) return true;
        }
        return false;
    }

});