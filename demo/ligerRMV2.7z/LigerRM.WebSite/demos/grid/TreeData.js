﻿var TreeData = { Rows: [
        { id: '01',  
            children: [
            { id: '0101', amount:400 },
            { id: '0102',  children:
                [
                    { id: '010201', amount: 200 },
                    { id: '010202', amount: 100 }
                ]
            },
           { id: '0103', amount: 100 }
        ]
        },
        { id: '02', amount: 100 },
        { id: '03', amount: 100 }  
    ]  
};