﻿using System.Collections.Generic;
using Liger.Common.Extensions;
using System;

namespace LigerRM.Common
{
    public sealed class SysContext
    {
        public static void SetCurrent(int userid)
        {
            CurrentUserID = userid; 
        }

        public static void ClearUserStatus()
        {
            CookieHelper.SetCookie("CurrentUserID", "0", DateTime.Now);
        }

        /// <summary>
        /// 当前用户角色 多个用逗号隔开
        /// </summary>
        public static string CurrentRoleID
        {
            get
            {
                try
                {
                    return CookieHelper.GetCookieValue("CurrentRoleID").ToStr();
                }
                catch
                {
                    return "0";
                }
            }
            set
            {
                var cookie = CookieHelper.GetCookie("CurrentRoleID");
                if (cookie != null)
                {
                    CookieHelper.SetCookie("CurrentRoleID", value, DateTime.Now.AddHours(1));
                }
                else
                {
                    //有效期，一个钟头
                    CookieHelper.AddCookie("CurrentRoleID", value, DateTime.Now.AddHours(1));
                }

            }
        }
        /// <summary>
        /// 当前用户部门
        /// </summary>
        public static int CurrentDeptID
        {
            get
            {
                try
                {
                    return CookieHelper.GetCookieValue("CurrentDeptID").ToInt();
                }
                catch
                {
                    return 0;
                }
            }
            set
            {
                var cookie = CookieHelper.GetCookie("CurrentDeptID");
                if (cookie != null)
                {
                    CookieHelper.SetCookie("CurrentDeptID", value.ToStr(), DateTime.Now.AddHours(1));
                }
                else
                {
                    //有效期，一个钟头
                    CookieHelper.AddCookie("CurrentDeptID", value.ToStr(), DateTime.Now.AddHours(1));
                } 
            }
        }

        /// <summary>
        /// 供应商ID 如果当前用户是供应商，需要这个
        /// </summary>
        public static int CurrentSupplierID
        {
            get
            {
                try
                {
                    return CookieHelper.GetCookieValue("CurrentSupplierID").ToInt();
                }
                catch
                {
                    return 0;
                }
            }
            set
            {
                var cookie = CookieHelper.GetCookie("CurrentSupplierID");
                if (cookie != null)
                {
                    CookieHelper.SetCookie("CurrentSupplierID", value.ToStr(), DateTime.Now.AddHours(1));
                }
                else
                {
                    //有效期，一个钟头
                    CookieHelper.AddCookie("CurrentSupplierID", value.ToStr(), DateTime.Now.AddHours(1));
                }
            }
        }

        /// <summary>
        /// 用户ID
        /// </summary>
        public static int CurrentUserID
        {
            get
            {
                try
                {
                    return CookieHelper.GetCookieValue("CurrentUserID").ToInt();
                }
                catch
                {
                    return 0;
                }
            }
            set
            {
                var cookie = CookieHelper.GetCookie("CurrentUserID");
                if (cookie != null)
                {
                    CookieHelper.SetCookie("CurrentUserID", value.ToStr(), DateTime.Now.AddHours(1));
                }
                else
                {
                    //有效期，一个钟头
                    CookieHelper.AddCookie("CurrentUserID", value.ToStr(), DateTime.Now.AddHours(1));
                }
                
            }
        }



        public static int CurrentEmployeeID
        {
            get
            {
                try
                {
                    return CookieHelper.GetCookieValue("CurrentEmployeeID").ToInt();
                }
                catch
                {
                    return 0;
                }
            }
            set
            {
                var cookie = CookieHelper.GetCookie("CurrentEmployeeID");
                if (cookie != null)
                {
                    CookieHelper.SetCookie("CurrentEmployeeID", value.ToStr(), DateTime.Now.AddHours(1));
                }
                else
                {
                    //有效期，一个钟头
                    CookieHelper.AddCookie("CurrentEmployeeID", value.ToStr(), DateTime.Now.AddHours(1));
                }
            }
        }



        /// <summary>
        /// 上次登录时间
        /// </summary>
        public static string CurrentUserLastLoginTime
        {
            get
            {
                  return CookieHelper.GetCookieValue("CurrentUserLastLoginTime"); 
            }
            set
            {
                var cookie = CookieHelper.GetCookie("CurrentUserLastLoginTime");
                if (cookie != null)
                {
                    CookieHelper.SetCookie("CurrentUserLastLoginTime", value.ToStr(), DateTime.Now.AddHours(1));
                }
                else
                {
                    //有效期，一个钟头
                    CookieHelper.AddCookie("CurrentUserLastLoginTime", value.ToStr(), DateTime.Now.AddHours(1));
                }
            }
        }



        public static string CurrentUserTitle
        {
            get
            {
                try
                {
                    return CookieHelper.GetCookieValue("CurrentUserTitle").ToStr();
                }
                catch
                {
                    return "0";
                }
            }
            set
            {
                var cookie = CookieHelper.GetCookie("CurrentUserTitle");
                if (cookie != null)
                {
                    CookieHelper.SetCookie("CurrentUserTitle", value, DateTime.Now.AddHours(1));
                }
                else
                {
                    //有效期，一个钟头
                    CookieHelper.AddCookie("CurrentUserTitle", value, DateTime.Now.AddHours(1));
                }

            }
        }
    }
}
