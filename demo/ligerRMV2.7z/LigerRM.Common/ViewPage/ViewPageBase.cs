﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using Liger.Data;
using System.Web.UI; 

namespace LigerRM.Common
{
    /// <summary>
    /// 带权限控制的页面基类
    /// </summary>
    public class ViewPageBase : System.Web.UI.Page 
    {
        /// <summary>
        /// 权限控制
        /// </summary>
        private void CheckPermission()
        {
            //权限判断
            if (SysContext.CurrentUserID == 0)
            {
                Response.Redirect("~/login.htm?FromUrl=" + HttpUtility.UrlEncode(Request.Url.AbsoluteUri));
            }
        }

        protected override void OnPreInit(EventArgs e)
        {
            base.OnPreInit(e);
            this.CheckPermission();
        }  
    }
}
